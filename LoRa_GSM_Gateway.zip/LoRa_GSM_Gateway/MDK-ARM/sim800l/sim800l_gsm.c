#include "sim800l_gsm.h"


char rx_buff_apn[50];
char rx_buff_tcp[400];
char rx_buff_get_ip[50];
char rx_buff_sim_test[100];
char rx_buff_connect_gprs[50];
char rx_buff_send_packet[100];
char rx_buffcloseTCP[100];
char check_tcp_connect[20];
char rx_buff_query_tcp[200];

void send_AT_command(uint8_t* command,int length)
{
   HAL_UART_Transmit(&huart1,(uint8_t*)command,length,100);
}
void set_apn(char* apn)
{
	memset(rx_buff_apn,0,50);
	char tx_buff_apn[100]="AT+CSTT=\"";
	strncat(tx_buff_apn,apn,strlen(apn));
	strncat(tx_buff_apn,"\",\"\",\"\"\r\n",9);
	HAL_UART_Transmit(&huart1,(uint8_t*)tx_buff_apn,strlen(tx_buff_apn),100);
	HAL_UART_Receive(&huart1, (uint8_t*)rx_buff_apn,50, 100);  // Receiving data via usart
	
	//memset(tx_buff_apn,0,50);
	
}

int start_tcp(char* ip,char* port)
{
	memset(rx_buff_tcp,0,400);
	char tx_buff_tcp[100]="AT+CIPSTART=\"TCP\",\"";
	strncat(tx_buff_tcp,ip,strlen(ip));
	strncat(tx_buff_tcp,"\",\"",3);
	strncat(tx_buff_tcp,port,strlen(port));
	strncat(tx_buff_tcp,"\"\r\n",3);
	HAL_UART_Transmit(&huart1,(uint8_t*)tx_buff_tcp,strlen(tx_buff_tcp),100);
	HAL_UART_Receive(&huart1, (uint8_t*)rx_buff_tcp,(strlen(tx_buff_tcp)+8+10), 15000);  // Receiving data via usart
	for(int j=(strlen(tx_buff_tcp)+8);j<(strlen(tx_buff_tcp)+15);j++)
	{
		check_tcp_connect[j-(strlen(tx_buff_tcp)+8)]=rx_buff_tcp[j];
	}
	if(strcmp(check_tcp_connect,"CONNECT")==0)
	{
		memset(check_tcp_connect,0,20);
		return 1;
	}
	else
	{
		return 0;
	}
	
	//memset(rx_buff_tcp,0,50);
	//memset(tx_buff_tcp,0,50);
}

void get_ip(char*ip)
{
	memset(rx_buff_get_ip,0,50);
	char tx_vuff_get_ip[100]="AT+CIFSR\r\n";
	HAL_UART_Transmit(&huart1,(uint8_t*)tx_vuff_get_ip,strlen(tx_vuff_get_ip),100);
	HAL_UART_Receive(&huart1, (uint8_t*)rx_buff_get_ip,50, 100);  // Receiving data via usart
	
}
void closeTCP(void)
{
	memset(rx_buffcloseTCP,0,100);
	char tx_vuffcloseTCP[100]="AT+CIPSHUT\r\n";
	HAL_UART_Transmit(&huart1,(uint8_t*)tx_vuffcloseTCP,strlen(tx_vuffcloseTCP),100);
	HAL_UART_Receive(&huart1, (uint8_t*)rx_buffcloseTCP,50, 5000);  // Receiving data via usart
	
}
char length_in_char[10];
void send_packet_over_tcp(int length)
{
	memset(rx_buff_send_packet,0,100);
	char tx_buff_to_send_packet[100]="AT+CIPSEND=";
	sprintf(length_in_char,"%i\r\n",length);
	strncat(tx_buff_to_send_packet,length_in_char,strlen(length_in_char));
	HAL_UART_Transmit(&huart1,(uint8_t*)tx_buff_to_send_packet,strlen(tx_buff_to_send_packet),100);
	HAL_UART_Receive(&huart1, (uint8_t*)rx_buff_send_packet,50, 100);  // Receiving data via usart
}

void check_sim()
{
	memset(rx_buff_sim_test,0,100);
	char tx_vuff_sim_test[100]="AT+CGREG?\r\n";
	HAL_UART_Transmit(&huart1,(uint8_t*)tx_vuff_sim_test,strlen(tx_vuff_sim_test),100);
	HAL_UART_Receive(&huart1, (uint8_t*)rx_buff_sim_test,100, 100);  // Receiving data via usart
}

void query_status_tcp()
{
	memset(rx_buff_query_tcp,0,100);
	char tx_vuff_query_tcp[100]="AT+CIPSTATUS\r\n";
	HAL_UART_Transmit(&huart1,(uint8_t*)tx_vuff_query_tcp,strlen(tx_vuff_query_tcp),100);
	HAL_UART_Receive(&huart1, (uint8_t*)rx_buff_query_tcp,200, 20000);  // Receiving data via usart
}

void conect_gprs()
{
	memset(rx_buff_connect_gprs,0,50);
	char tx_vuff_connect_gprs[100]="AT+CIICR\r\n";
	HAL_UART_Transmit(&huart1,(uint8_t*)tx_vuff_connect_gprs,strlen(tx_vuff_connect_gprs),100);
	HAL_UART_Receive(&huart1, (uint8_t*)rx_buff_connect_gprs,100, 100);  // Receiving data via usart
}
char rx_buff_tcp_transparent[50];
void set_tcp_transparent()
{
	memset(rx_buff_tcp_transparent,0,50);
	char tx_vuff_tcp_transparent[100]="AT+CIPMODE=1\r\n";
	HAL_UART_Transmit(&huart1,(uint8_t*)tx_vuff_tcp_transparent,strlen(tx_vuff_tcp_transparent),100);
	HAL_UART_Receive(&huart1, (uint8_t*)rx_buff_tcp_transparent,100, 100);  // Receiving data via usart
}

void send_mqtt_packet(int length,char* packet)
{
	HAL_UART_Transmit(&huart1,(uint8_t*)packet,length,100);
}


