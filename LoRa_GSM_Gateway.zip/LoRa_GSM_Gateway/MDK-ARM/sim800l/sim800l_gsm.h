#ifndef __SIM800L_GSM_H
#define __SIM800L_GSM_H

#include "string.h"
#include "stdbool.h"
#include "stm32f1xx_hal.h"

void send_AT_command(uint8_t* command,int length);
void set_apn(char* apn);
int start_tcp(char* ip,char* port);
void get_ip(char*ip);
void check_sim(void);
void conect_gprs(void);
void send_packet_over_tcp(int length);
void send_mqtt_packet(int length,char* packet);
void closeTCP(void);
void set_tcp_transparent();
void query_status_tcp();
extern UART_HandleTypeDef huart1;


#endif
