				********************************
					LoRa_GSM_Gateway
				********************************

NOTE: Don't generate code using cubemx (Some config was manually set)

Objective :	Poles data from the nodes and waits for the data from the nodes and then publishes it to the server through MQTT using GPRS 


TIM3 :	Prescaler-32000			Counter-2000
IDWG :	IWDG_PRESCALER_64		4095

SPI1 	:	For LoRa Module (Default settings)
USART1 	:	For GSM Module

GPIO :	PA4		LoRa_NSS
	PB0		DIO_0
	PB14		LED



Clock:	32 MHz


Libs used:	sx1276_7_8		LoRa Lib
		spi			SPI lib for communication between microcontroller and LoRa module
		sim800l			GSM lib
		packet_mqtt		MQTT lib
		
		


Parameters:	Parameter		Discription				File Name
		
		FREQ_CHANNEL		Lora frequency				main.c
		Power_Sel		Tx Power				main.c
		Lora_Rate_Sel		spreading factor			main.c
		CR_4_5			Error Coding rate (CR)setting		sx1276_7_8.h
		

Functions:	Function				Discription	


